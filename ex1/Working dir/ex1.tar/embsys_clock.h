#ifndef EMBSYS_CLOCK_H_
#define EMBSYS_CLOCK_H_

#define EMBSYS_CLOCK_ADDR (0x100)

unsigned int embsys_clock_read();

#endif /*EMBSYS_CLOCK_H_*/
