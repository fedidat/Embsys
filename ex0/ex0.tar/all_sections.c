const int a = 5;
int b = 5;
int c;

void _start()
{
    main();
}

int main()
{
    return 0;
}
