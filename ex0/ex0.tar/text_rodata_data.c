const int a = 5;
int b = 5;

void _start()
{
    main();
}

int main()
{
    return 0;
}
