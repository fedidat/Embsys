void _start()
{
    main();
}

int main()
{
    return 0;
}
