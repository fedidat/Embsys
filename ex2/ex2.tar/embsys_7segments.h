#ifndef EMBSYS_7SEGMENTS_H_
#define EMBSYS_7SEGMENTS_H_

#define EMBSYS_7SEGMENTS_ADDR (0x104)

void embsys_7segments_write(char value);

#endif /*EMBSYS_7SEGMENTS_H_*/

